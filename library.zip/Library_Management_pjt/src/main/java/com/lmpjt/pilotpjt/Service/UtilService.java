package com.lmpjt.pilotpjt.Service;

public interface UtilService {
    public int getTotalBooks();
    public int getTotalUsers();
    public int getBorrowedBooks();
    public int getOverdueBooks();
}
